<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ElFinderInputWidget
 *
 * @author root
 */
class ElFinderInputWidget extends ElFinderWidget
{
    public function run()
    {
        
    }
    //put your code here
}