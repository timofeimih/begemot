<?php
if ($_SERVER["SERVER_NAME"] == "phpcrawl.cuab.de")
{
?>
-->
<script language="javascript">
url = document.location.toString();
if (url.match(/example/))
  document.getElementById("page").style.width = "1150px";
else
  document.getElementById("page").style.width = "1000px";
</script>
  
<div id="right">
<script type="text/javascript"><!--
google_ad_client = "ca-pub-4351312586851155";
/* phpcrawl */
google_ad_slot = "1565633989";
google_ad_width = 160;
google_ad_height = 600;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>
  
<script language="javascript">
if (url.match(/example/))
  document.getElementById("right").style.marginLeft = "190px";
</script>
<!--
<?php
}
?>